class AnimatedLabel(tk.Label):
    def __init__(self, master, on_gif_path, off_gif_path, **kwargs):
        self.on_frames = []
        self.off_frames = []
        
        # Load ON animation
        try:
            on_gif = Image.open(on_gif_path)
            for i in range(on_gif.n_frames):
                frame = ImageTk.PhotoImage(on_gif.copy())
                self.on_frames.append(frame)
                on_gif.seek(i + 1)
        except Exception as e:
            print(f"Error loading ON GIF: {e}")
        
        # Load OFF animation
        try:
            off_gif = Image.open(off_gif_path)  # This is correct here
            for i in range(off_gif.n_frames):
                frame = ImageTk.PhotoImage(off_gif.copy())
                self.off_frames.append(frame)
                off_gif.seek(i + 1)
        except Exception as e:
            print(f"Error loading OFF GIF: {e}")

        tk.Label.__init__(self, master, image=self.off_frames[0], **kwargs)
        self.current_frames = self.off_frames
        self.current_frame = 0
        self.delay = 100
        self.running = False