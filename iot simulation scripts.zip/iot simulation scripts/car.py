import pygame
import firebase_admin
from firebase_admin import credentials, db
import time
import threading

# Initialize Firebase
cred = credentials.Certificate(r"C:\iot\shetkari-mitra-7721-firebase-adminsdk-822ho-5ae3d18c8e.json")
firebase_admin.initialize_app(cred, {
    'databaseURL': "https://shetkari-mitra-7721-default-rtdb.firebaseio.com/"
})

# Initialize Pygame
pygame.init()

# Screen dimensions
WIDTH, HEIGHT = 800, 600
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Carbon View: Sustain Today, Secure Tomorrow")

# Load Images
road = pygame.image.load("road2.png")
road = pygame.transform.scale(road, (WIDTH, HEIGHT * 2))
car = pygame.image.load("car3.png").convert_alpha()
car = pygame.transform.scale(car, (100, 200))
bike = pygame.image.load("bike.png").convert_alpha()
bike = pygame.transform.scale(bike, (80, 160))
app_logo = pygame.image.load("logo.png")  
app_logo = pygame.transform.scale(app_logo, (80, 80))  

# Vehicle Properties
car_x, car_y = WIDTH // 3 - 50, HEIGHT - 220
bike_x, bike_y = 2 * WIDTH // 3 - 50, HEIGHT - 220
speed = 0
running = False
car_km_counter = 0
bike_km_counter = 0
road_y = 0

# Firebase References
car_ref = db.reference("car_data")
bike_ref = db.reference("bike_data")
car_name = "MyCar"
bike_name = "MyBike"

# Colors
WHITE, BLACK, GREEN, RED = (255, 255, 255), (0, 0, 0), (0, 200, 0), (200, 0, 0)

# Fonts
font = pygame.font.Font(None, 36)
heading_font = pygame.font.Font(None, 48)

# Buttons
start_button = pygame.Rect(50, HEIGHT - 70, 120, 50)
stop_button = pygame.Rect(200, HEIGHT - 70, 120, 50)

def draw_text(text, font, color, x, y):
    """Function to draw text on screen."""
    text_surface = font.render(text, True, color)
    screen.blit(text_surface, (x, y))

def store_data_to_firebase():
    """Function to store data in Firebase."""
    global car_km_counter, bike_km_counter
    timestamp = time.strftime("%Y-%m-%d %H:%M:%S")

    def upload_car():
        car_ref.push({"car_name": car_name, "car_current_km": car_km_counter, "timestamp": timestamp})
        print("Car Data Uploaded")

    def upload_bike():
        bike_ref.push({"bike_name": bike_name, "bike_current_km": bike_km_counter, "timestamp": timestamp})
        print("Bike Data Uploaded")

    threading.Thread(target=upload_car, daemon=True).start()
    threading.Thread(target=upload_bike, daemon=True).start()
    car_km_counter = 0
    bike_km_counter = 0

# Main Loop
clock = pygame.time.Clock()
running_game = True

while running_game:
    screen.fill(BLACK)
    road_y += speed * 2
    if road_y >= HEIGHT:
        road_y = 0
    screen.blit(road, (0, road_y - HEIGHT))
    screen.blit(road, (0, road_y))
    screen.blit(car, (car_x, car_y))
    screen.blit(bike, (bike_x, bike_y))

    # Positioning Elements
    screen.blit(app_logo, (20, 10))  # Logo at top left
    draw_text("Carbon View: Sustain Today, Secure Tomorrow", heading_font, GREEN, 20, 100)  # Heading below logo

    # Speedometer at top right (Color changes based on running state)
    speed_color = GREEN if running else RED
    draw_text(f"Speed: {int(speed * 10)} km/h", font, speed_color, WIDTH - 180, 20)

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running_game = False
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_UP:
                running = True
            elif event.key == pygame.K_DOWN:
                running = False
        elif event.type == pygame.MOUSEBUTTONDOWN:
            if start_button.collidepoint(event.pos):
                running = True
            elif stop_button.collidepoint(event.pos):
                running = False

    if running:
        speed = min(speed + 0.1, 10)
        car_km_counter += speed / 100
        bike_km_counter += speed / 100
        if car_km_counter >= 5 or bike_km_counter >= 5:
            store_data_to_firebase()
    else:
        speed = max(speed - 0.2, 0)

    # Buttons at bottom left
    pygame.draw.rect(screen, GREEN if running else WHITE, start_button)
    pygame.draw.rect(screen, RED if not running else WHITE, stop_button)
    draw_text("START", font, BLACK, start_button.x + 25, start_button.y + 10)
    draw_text("STOP", font, BLACK, stop_button.x + 35, stop_button.y + 10)

    pygame.display.update()
    clock.tick(30)

pygame.quit()
