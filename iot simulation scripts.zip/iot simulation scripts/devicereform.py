import tkinter as tk
from tkinter import ttk
import firebase_admin
from firebase_admin import credentials
from firebase_admin import db
from datetime import datetime
import time
from PIL import Image, ImageTk
import threading
from queue import Queue
from dataclasses import dataclass

# Initialize Firebase
cred = credentials.Certificate(r"C:\iot\shetkari-mitra-7721-firebase-adminsdk-822ho-5ae3d18c8e.json")
firebase_admin.initialize_app(cred, {
    'databaseURL': "https://shetkari-mitra-7721-default-rtdb.firebaseio.com/"
})

# Firebase references
user_devices_ref = db.reference('UserDevices')
realtime_devices_ref = db.reference('UserRealtimeDevices')

@dataclass
class DeviceState:
    state: str = "Off"
    start_time: float = None
    running: bool = False
    total_time: float = 0.0
    total_emissions: float = 0.0
    solar_running_time: float = 0.0
    data: dict = None

class CarbonViewApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Carbon View")
        self.root.geometry("1200x800")

        # Global state
        self.energy_source = "Grid Electricity"
        self.device_states = {}
        self.update_queue = Queue()
        self.devices = []

        # Load images
        self.on_image = ImageTk.PhotoImage(Image.open("on_image.png").resize((50, 50)))
        self.off_image = ImageTk.PhotoImage(Image.open("off_image.png").resize((50, 50)))
        self.solar_image = ImageTk.PhotoImage(Image.open("solar_image.png").resize((50, 50)))

        # UI setup
        self.setup_ui()
        self.fetch_devices()
        self.start_workers()

    def setup_ui(self):
        tk.Label(self.root, text="Carbon View", font=("Arial", 24, "bold")).pack(pady=20)

        energy_frame = tk.Frame(self.root)
        energy_frame.pack(pady=10)
        self.elec_btn = tk.Button(energy_frame, text="Turn On Electricity", bg="green", fg="white",
                                  command=lambda: self.set_energy_source("Grid Electricity"))
        self.elec_btn.pack(side=tk.LEFT, padx=10)
        self.solar_btn = tk.Button(energy_frame, text="Turn On Solar", bg="gray", fg="white",
                                   command=lambda: self.set_energy_source("Solar"))
        self.solar_btn.pack(side=tk.LEFT, padx=10)

        self.home_frame = tk.LabelFrame(self.root, text="Home Appliances", font=("Arial", 14), padx=10, pady=10)
        self.home_frame.pack(fill="x", padx=20, pady=10)
        self.industrial_frame = tk.LabelFrame(self.root, text="Industrial Devices", font=("Arial", 14), padx=10, pady=10)
        self.industrial_frame.pack(fill="x", padx=20, pady=10)

    def fetch_devices(self):
        devices_data = user_devices_ref.get()
        if devices_data:
            for device_id, data in devices_data.items():
                device = {
                    "deviceId": data.get("deviceId", device_id),
                    "deviceName": data.get("deviceName", "Unknown Device"),
                    "powerRating": float(data.get("powerRating", 0.0)),
                    "co2EmissionFactor": float(data.get("co2EmissionFactor", 0.4)),
                    "energySource": data.get("energySource", "Grid Electricity"),
                }
                self.devices.append(device)
                realtime_data = realtime_devices_ref.child(device["deviceId"]).get() or {}
                self.device_states[device["deviceName"]] = DeviceState(
                    state=realtime_data.get("state", "Off"),
                    total_time=float(realtime_data.get("totalTime", 0.0)),
                    total_emissions=float(realtime_data.get("totalEmissions", 0.0)),
                    solar_running_time=float(realtime_data.get("solarRunningTime", "0")),
                    data=realtime_data.get("data", {}) or {}
                )
                # Initialize full RealtimeDevice structure in Firebase if not present
                if not realtime_data:
                    realtime_devices_ref.child(device["deviceId"]).set({
                        "deviceId": device["deviceId"],
                        "deviceName": device["deviceName"],
                        "powerRating": device["powerRating"],
                        "co2EmissionFactor": device["co2EmissionFactor"],
                        "energySource": device["energySource"],
                        "totalTime": 0.0,
                        "totalEmissions": 0.0,
                        "solarRunningTime": "0",
                        "state": "Off",
                        "data": {}
                    })
                self.create_device_ui(device)
        print(f"Fetched {len(self.devices)} devices")

    def create_device_ui(self, device):
        frame = self.home_frame if any(x in device["deviceName"] for x in ["Fan", "Refrigerator", "Air Conditioner", "Washing Machine"]) else self.industrial_frame
        device_frame = tk.Frame(frame)
        device_frame.pack(fill="x", pady=5)

        img_label = tk.Label(device_frame, image=self.off_image)
        img_label.pack(side=tk.LEFT, padx=5)

        metadata = f"{device['deviceName']} (Power: {device['powerRating']} kW, CO2: {device['co2EmissionFactor']})"
        tk.Label(device_frame, text=metadata, font=("Arial", 12), width=40).pack(side=tk.LEFT, padx=5)

        on_btn = tk.Button(device_frame, text="ON", bg="gray", fg="white", width=10)
        off_btn = tk.Button(device_frame, text="OFF", bg="red", fg="white", width=10)
        on_btn.pack(side=tk.LEFT, padx=5)
        off_btn.pack(side=tk.LEFT, padx=5)

        on_btn.config(command=lambda: self.toggle_device(device, "On", on_btn, off_btn, img_label))
        off_btn.config(command=lambda: self.toggle_device(device, "Off", on_btn, off_btn, img_label))

    def calculate_emissions(self, power_rating, co2_factor, running_time):
        running_time_hours = running_time / 3600
        emissions = power_rating * co2_factor * running_time_hours if self.energy_source == "Grid Electricity" else 0.0
        return running_time_hours, emissions

    def toggle_device(self, device, state, on_btn, off_btn, img_label):
        current_state = self.device_states[device["deviceName"]]
        device_ref = realtime_devices_ref.child(device["deviceId"])
        if state == "On" and current_state.state == "Off":
            current_state.state = "On"
            current_state.start_time = time.time()
            current_state.running = True
            on_btn.config(bg="green", text="ON (Running)")
            off_btn.config(bg="gray", text="OFF")
            img_label.config(image=self.solar_image if self.energy_source == "Solar" else self.on_image)
            self.update_queue.put((device_ref, {
                "deviceId": device["deviceId"],
                "deviceName": device["deviceName"],
                "powerRating": device["powerRating"],
                "co2EmissionFactor": device["co2EmissionFactor"],
                "energySource": self.energy_source,
                "totalTime": current_state.total_time,
                "totalEmissions": current_state.total_emissions,
                "solarRunningTime": str(current_state.solar_running_time),
                "state": "On",
                "data": current_state.data
            }))
            print(f"Toggled {device['deviceName']} to On - Running: {current_state.running}")
        elif state == "Off" and current_state.state == "On":
            running_time = time.time() - current_state.start_time
            running_time_hours, emissions = self.calculate_emissions(device["powerRating"], device["co2EmissionFactor"], running_time)
            current_state.state = "Off"
            current_state.start_time = None
            current_state.running = False
            current_state.total_time += running_time_hours
            current_state.total_emissions += emissions
            current_state.solar_running_time += running_time_hours if self.energy_source == "Solar" else 0
            current_date = datetime.now().strftime("%Y-%m-%d")
            daily_data = current_state.data.get(current_date, {"emissions": 0.0, "time": 0.0, "km": 0.0})
            daily_data["emissions"] += emissions
            daily_data["time"] += running_time_hours
            current_state.data[current_date] = daily_data

            on_btn.config(bg="gray", text="ON")
            off_btn.config(bg="red", text="OFF (Stopped)")
            img_label.config(image=self.off_image)
            self.update_queue.put((device_ref, {
                "deviceId": device["deviceId"],
                "deviceName": device["deviceName"],
                "powerRating": device["powerRating"],
                "co2EmissionFactor": device["co2EmissionFactor"],
                "energySource": self.energy_source,
                "totalTime": current_state.total_time,
                "totalEmissions": current_state.total_emissions,
                "solarRunningTime": str(current_state.solar_running_time),
                "state": "Off",
                "data": current_state.data
            }))
            print(f"Toggled {device['deviceName']} to Off - Running: {current_state.running}")

    def set_energy_source(self, source):
        self.energy_source = source
        self.elec_btn.config(bg="green" if source == "Grid Electricity" else "gray")
        self.solar_btn.config(bg="green" if source == "Solar" else "gray")
        for device in self.devices:
            if self.device_states[device["deviceName"]].running:
                device_frame = next((f for f in (self.home_frame.winfo_children() + self.industrial_frame.winfo_children()) 
                                     if f.winfo_children()[1].cget("text").startswith(device["deviceName"])), None)
                if device_frame:
                    img_label = device_frame.winfo_children()[0]
                    img_label.config(image=self.solar_image if self.energy_source == "Solar" else self.on_image)
                # Update energySource in Firebase for running devices
                device_ref = realtime_devices_ref.child(device["deviceId"])
                self.update_queue.put((device_ref, {
                    "deviceId": device["deviceId"],
                    "deviceName": device["deviceName"],
                    "powerRating": device["powerRating"],
                    "co2EmissionFactor": device["co2EmissionFactor"],
                    "energySource": self.energy_source,
                    "totalTime": self.device_states[device["deviceName"]].total_time,
                    "totalEmissions": self.device_states[device["deviceName"]].total_emissions,
                    "solarRunningTime": str(self.device_states[device["deviceName"]].solar_running_time),
                    "state": self.device_states[device["deviceName"]].state,
                    "data": self.device_states[device["deviceName"]].data
                }))
        print(f"Energy source set to {source}")

    def update_all_devices(self):
        current_date = datetime.now().strftime("%Y-%m-%d")
        running_count = 0
        for device in self.devices:
            state = self.device_states[device["deviceName"]]
            device_ref = realtime_devices_ref.child(device["deviceId"])
            if state.running and state.start_time:
                running_time = time.time() - state.start_time
                running_time_hours, emissions = self.calculate_emissions(device["powerRating"], device["co2EmissionFactor"], running_time)
                state.total_time += running_time_hours  # Accumulate instead of reset
                state.total_emissions += emissions
                state.solar_running_time += running_time_hours if self.energy_source == "Solar" else 0
                daily_data = state.data.get(current_date, {"emissions": 0.0, "time": 0.0, "km": 0.0})
                daily_data["emissions"] += emissions
                daily_data["time"] += running_time_hours
                state.data[current_date] = daily_data

                self.update_queue.put((device_ref, {
                    "deviceId": device["deviceId"],
                    "deviceName": device["deviceName"],
                    "powerRating": device["powerRating"],
                    "co2EmissionFactor": device["co2EmissionFactor"],
                    "energySource": self.energy_source,
                    "totalTime": state.total_time,
                    "totalEmissions": state.total_emissions,
                    "solarRunningTime": str(state.solar_running_time),
                    "state": "On",
                    "data": state.data
                }))
                running_count += 1
            print(f"Device {device['deviceName']} - Running: {state.running}, Start Time: {state.start_time}")
        print(f"Updated {running_count} running devices")
        self.root.after(5000, self.update_all_devices)

    def firebase_update_worker(self):
        while True:
            try:
                device_ref, data = self.update_queue.get(timeout=1)
                device_ref.update(data)
                self.update_queue.task_done()
                print(f"Firebase updated for {data.get('deviceName', 'unknown')}")
            except:
                time.sleep(1)

    def start_workers(self):
        threading.Thread(target=self.firebase_update_worker, daemon=True).start()
        self.root.after(5000, self.update_all_devices)

if __name__ == "__main__":
    root = tk.Tk()
    app = CarbonViewApp(root)
    root.mainloop()